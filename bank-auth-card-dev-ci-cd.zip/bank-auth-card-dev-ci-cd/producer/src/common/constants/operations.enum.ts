export enum Operations {
  LOGIN = 'LOGIN',
}
