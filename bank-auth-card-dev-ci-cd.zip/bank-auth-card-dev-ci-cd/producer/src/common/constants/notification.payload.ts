export const BANK_LINK_PAYLOAD_PAYLOAD = {
  'employee_idx': '',
  'action_alias': 'bank_account_linked',
  'data': [
    // {
    //   'key': 'employee_name',
    //   'value': 'Spider Man'
    // },
    // {
    //   'key': 'bank_acc_number',
    //   'value': '222'
    // }
  ],
  label: `SINGLE_NOTIFICATION`,
};

export const DEBIT_CARD_REQUEST_PAYLOAD = {
  'employee_idx': '',
  'action_alias': 'debit_card_requested',
  'data': [
    // {
    //   'key': 'employee_name',
    //   'value': 'Spider Man'
    // }
  ],
  label: `SINGLE_NOTIFICATION`,
};

export const SALARY_ADVANCE_DEPOSITED_DEBIT_CARD = {
  'employee_idx': '',
  'action_alias': 'salary_advance_deposited_in_debit_card',
  'data': [
    // {
    //   'key': 'employee_name',
    //   'value': 'Spider Man'
    // },
    // {
    //   'key': 'Amount',
    //   'value': 'Spider Man'
    // },
    // {
    //   'key': 'currency',
    //   'value': 'USD'
    // }
  ],
  label: `SINGLE_NOTIFICATION`,
};