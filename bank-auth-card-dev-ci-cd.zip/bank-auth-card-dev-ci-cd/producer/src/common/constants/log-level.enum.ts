export enum LogLevel {
    INFO = 'INFO',
    ERROR = 'ERROR',
    DEBUG = 'DEBUG',
    WARN = 'WARN',
    FATAL = 'FATAL',
}
