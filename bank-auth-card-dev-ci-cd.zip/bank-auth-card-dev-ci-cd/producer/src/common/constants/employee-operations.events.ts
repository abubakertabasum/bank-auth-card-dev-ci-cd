export const CARD_ADDED_SUCCESSFULLY = {
    name: 'Card added successfully',
    paramCode: 'EMPLOYEEOP-OP-001',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#info', '#success']
}

export const UNABLE_TO_ADD_CARD = {
    name: 'Unable to add card',
    paramCode: 'EMPLOYEEOP-OP-001',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#error', '#failure']
}

export const UNABLE_TO_VIEW_LIST_OF_ADDED_CARDS = {
    name: 'Unable to view list of added cards',
    paramCode: 'EMPLOYEEOP-OP-002',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#error', '#failure']
}

export const ABLE_TO_REMOVE_THE_CARD_SUCCESSFULLY = {
    name: 'Able to remove the card successfully',
    paramCode: 'EMPLOYEEOP-OP-003',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#info', '#success']
}

export const UNABLE_TO_REMOVE_CARDS = {
    name: 'Unable to remove cards',
    paramCode: 'EMPLOYEEOP-OP-003',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#error', '#failure']
}

export const CARD_UPDATED_SUCCESSFULLY = {
    name: 'Card updated successfully',
    paramCode: 'EMPLOYEEOP-OP-004',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#info', '#success']
}

export const UNABLE_TO_UPDATE_THE_CARD = {
    name: 'Unable to update the card',
    paramCode: 'EMPLOYEEOP-OP-004',
    tags: ['#employeeops', '#employeenonfinancialactivities', "#bankcard", '#error', '#failure']
}
