export interface IResponse {
  statusCode: number;
  message: string;
}
