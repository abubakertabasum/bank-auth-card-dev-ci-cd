export interface ServiceBusTopicInterface {
    name: string;
    primaryKey: string;
    SecondaryKey?: string;
}
