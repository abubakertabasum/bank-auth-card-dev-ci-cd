export interface LogEventInterface {
    name: string,
    paramCode: string,
    tags: string[]
}