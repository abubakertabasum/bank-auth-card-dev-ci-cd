export function getPaycyclePeriod(startDate: Date, paymentCycle: string) {
  const now = new Date(startDate);

  return new Date();
}
