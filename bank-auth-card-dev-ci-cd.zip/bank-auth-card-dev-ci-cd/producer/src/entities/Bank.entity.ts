import {
Column,
Entity,
Generated,
Index,
PrimaryGeneratedColumn,
} from 'typeorm';
import { Exclude, Transform } from 'class-transformer';


@Index(['account_number'], { unique: true })
@Entity('Bank', { schema: 'dbo' })
export class Bank {
  @Column('uuid', {
  nullable: false,
  name: 'idx',
  })
  @Generated('uuid')
  idx: string;

  @Column('datetime', {
  name: 'created_on',
  default: () => 'getdate()',
  })
  created_on: Date;


  @Exclude({ toPlainOnly: true })
  @PrimaryGeneratedColumn({
  type: 'integer',
  name: 'id',
  })
  id: number;
  @Exclude({ toPlainOnly: true })
  @Column('bit', {
  nullable: false,
  default: () => '(0)',
  name: 'is_obsolete',
  })
  is_obsolete: boolean;

  @Exclude({ toPlainOnly: true })
  @Column('datetime', {
  nullable: true,
  default: () => 'getdate()',
  name: 'modified_on',
  })
  modified_on: Date | null;

  @Column('varchar', { length: 150, name: 'account_number' })
  account_number: string;

  @Column('varchar', { length: 150, name: 'account_balance', nullable: true })
  account_balance: string | null;

  @Column('varchar', { length: 50, name: 'type', nullable: false })
  type: string;

}

export const enum BankAccountTypeEnum {
  EMPLOYER_BANK = 'EMPLOYER_BANK',
  EMPLOYEE_BANK = 'EMPLOYEE_BANK',
  EMPLOYEE_CARD = 'EMPLOYEE_CARD'
}