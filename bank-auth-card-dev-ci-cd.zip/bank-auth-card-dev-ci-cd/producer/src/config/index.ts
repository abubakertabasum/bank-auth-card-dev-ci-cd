import * as dotenv from 'dotenv';
import { decrypt } from '../utils/cipher';
import * as fs from 'fs';
import * as path from 'path';
var dotenvExpand = require('dotenv-expand')
let file = `${__dirname}/../../env/${process.env.NODE_ENV}.env`;

if (!fs.existsSync(path.resolve(file))) {
	file = `${__dirname}/../../env/dev.env`;
}

const dotEnvConfig = dotenv.config({ path: file, debug: false });
dotenvExpand.expand(dotEnvConfig);

const config = {
  appName: process.env.APP_NAME || 'bank-auth-card-producer',
  environment: process.env.NODE_ENV || 'dev',
  port: Number(process.env.APP_PORT),
  jwt: {
    secret: process.env.JWT_SECRET,
    access_expiry: Number(process.env.JWT_ACCESS_EXPIRY),
		refresh_expiry: Number(process.env.JWT_REFRESH_EXPIRY),
    expiresIn: Number(process.env.JWT_EXPIRES_IN)
  },
  db: {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT),
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    key: process.env.DB_KEY,
    iv: process.env.DB_IV
  },
  mailConfig: {
    user: 'testrosebay@gmail.com',
    pass: 'fiqzfcqmertbketo',
  },
  serviceBus: {
    endpoint: process.env.SB_SENDER_CONNECTION_ENDPOINT,
    accessKeyName: process.env.SB_SENDER_SHARED_ACCESS_KEY_NAME,
    topicLogging: {
      name: process.env.SB_SENDER_TOPIC_LOGGING,
      primaryKey: process.env.SB_SENDER_TOPIC_LOGGING_PRIMARY_KEY,
    },
    maxRetries: process.env.SB_SENDER_MAX_RETRIES
  },
  mailService: 'gmail',
  sbSenderConnectionStringTopic: process.env.SERVICE_BUS_CONNECTION_STRING_TOPIC,
  topicName: process.env.TOPIC_NAME,
  minio: {
    port: Number(process.env.MINIO_PORT),
    accessKey: process.env.MINIO_ACCESS_KEY,
    secretKey: process.env.MINIO_SECRET_KEY,
    bucket: process.env.MINIO_BUCKET,
    endpoint: process.env.MINIO_ENDPOINT,
    fileServer: process.env.MINIO_FILE_SERVE_URL
  },

  sbSenderMaxRetries: process.env.SB_SENDER_MAX_RETRIES,
  bankServiceType: process.env.ACTIVE_BANK_PROVIDER
};

console.info(config);
export default config;
