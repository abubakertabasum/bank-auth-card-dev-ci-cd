import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import config from '@config/index';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import * as compression from 'compression';
import * as helmet from 'helmet';
import { ValidationPipe } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { RequestSanitizerInterceptor } from '@common/interceptor/requestSanitizer.interceptor';

async function bootstrap() {
  console.log('Nest Factory create --> ' + config.port);
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  console.log('Inside bootstrap start  --> ' + config.port);
  // ================================
  // configureExpressSettings
  // ================================

  app.set('etag', 'strong');
  app.set('trust proxy', true);

  // =================================
  // configureNestGlobals
  // =================================

  app
    .use(compression())
    .use(helmet())
    .useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        transform: true,
        validationError: { target: false },
      }),
    )
    .useGlobalInterceptors(new RequestSanitizerInterceptor())
    .setGlobalPrefix('v1')
    .enableCors();

  app.useLogger(app.get(WINSTON_MODULE_NEST_PROVIDER));
  console.log('Before App listen on  --> ' + config.port);
  await app.listen(config.port);

  console.info(`Operation server running on 🚀 http://localhost:${config.port}`);
}

bootstrap();
