import { IsIn, IsNotEmpty, Length, Matches, IsOptional, IsBoolean } from 'class-validator';

export class CheckCardVender {

	@IsNotEmpty({ message: 'Card number is required' })
	@Length(16, 16, {
		message: 'Please enter a valid card number length (16)',
	})
	card_number: string;

}
