import { IsIn, IsNotEmpty, Length, Matches, IsOptional, IsBoolean } from 'class-validator';

export class NewCardDto {

	@IsNotEmpty({ message: 'Card number is required' })
	@Length(16, 16, {
		message: 'Please enter a valid card number length (16)',
	})
	card_number: string;


	@IsNotEmpty({ message: 'Expiry date is required' })
	@Matches(/^([0-9]{2})\/([0-9]{2})$/, {
		message: 'Expiry date must of format mm/yy',
	})
	expiry_date: string;

	@IsNotEmpty({ message: 'CVV is required' })
	@Length(3, 3, {
		message: 'Please enter a valid cvv',
	})
	cvv: string;

	@IsNotEmpty({ message: 'Type is required' })
	@IsIn(['DEBIT', 'CREDIT'], {
		message: 'Type must be either DEBIT or CREDIT',
	})
	type: string;

	@IsOptional({ message: 'nick_name is required' })
	nick_name: string;

	@IsNotEmpty({ message: 'is_primary is required' })
	@IsBoolean()
	is_primary: boolean;
}
