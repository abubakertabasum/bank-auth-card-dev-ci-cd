export class PaginationDto {
  page: number;
  offset: number;
  limit: number;
  request_type: string;
  order_by: string;
  search: any;
}
