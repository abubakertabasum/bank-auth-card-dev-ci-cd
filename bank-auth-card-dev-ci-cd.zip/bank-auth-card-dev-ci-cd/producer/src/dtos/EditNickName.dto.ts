import { IsIn, IsNotEmpty, Length, Matches, IsOptional, IsBoolean } from 'class-validator';

export class EditCardParamsDto {

	@IsOptional({ message: 'Nick name' })
	nick_name: string;

	@IsNotEmpty({ message:"card_idx is required"})
	card_idx: string;
}
