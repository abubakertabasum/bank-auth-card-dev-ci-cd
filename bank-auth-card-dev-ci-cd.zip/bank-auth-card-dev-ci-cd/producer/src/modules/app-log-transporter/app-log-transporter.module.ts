import { Module } from '@nestjs/common';
import { AppLogTransformerService } from './app-log-transformer.service';
import { AppLogTransporterService } from './app-log-transporter.service';
import { LogTransporterService } from './log-transporter.service';

@Module({
    imports: [],
    controllers: [],
    providers: [AppLogTransformerService, AppLogTransporterService, LogTransporterService],
    exports: [AppLogTransporterService],
})
export class AppLogTransporterModule { }
