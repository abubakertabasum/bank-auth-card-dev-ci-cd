import { ServiceBusClient, ServiceBusMessage } from '@azure/service-bus';
import { ServiceBusTopicInterface } from '@common/interfaces/serviceBusTopic.interface';
import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { uniqueID } from '@utils/helpers';
import * as config from '../../config/index';

@Injectable()
export class LogTransporterService {

  private readonly logger: Logger = new Logger(LogTransporterService.name);
  private readonly connectionString: string;
  private readonly maxRetries: number;
  constructor() {
    this.connectionString = 'Endpoint=' + config.default.serviceBus.endpoint
      + ';SharedAccessKeyName='
      + config.default.serviceBus.accessKeyName;
    this.maxRetries = Number(config.default.serviceBus.maxRetries);
  }


  /**
   * Send Single Message to Service Bus
   * @param {ServiceBusTopicInterface} topic - The name of the topic to send message
   * @param {any} message - The json body to send on Azure Service Bus
   */
  async sendMessage(topic: ServiceBusTopicInterface, message: any) {
    const sbConnection = this.connectionString
      + ';SharedAccessKey='
      + topic.primaryKey
      + ';EntityPath='
      + topic.name;

    this.logger.debug(sbConnection);

    this.logger.log('Trying to Send Message to service bus...');
    const sbClient = new ServiceBusClient(sbConnection, {
      retryOptions: { maxRetries: this.maxRetries },
    });

    // Create sender instance
    const sender = sbClient.createSender(topic.name);

    const sbMessage: ServiceBusMessage = {
      body: message,
      messageId: await uniqueID(),
    };

    this.logger.log('Message to be sent: ' + JSON.stringify(sbMessage));
    try {
      // Send Message to Service Bus
      await sender.sendMessages(sbMessage);
      this.logger.log('Message sent successfully');
      await sender.close();
    } catch (err) {
      this.logger.error(err);
      throw new HttpException(
        'Error on sending message to service bus',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    } finally {
      this.logger.log('Closing Service Bus Client connection...');
      await sbClient.close();
    }
  }
}
