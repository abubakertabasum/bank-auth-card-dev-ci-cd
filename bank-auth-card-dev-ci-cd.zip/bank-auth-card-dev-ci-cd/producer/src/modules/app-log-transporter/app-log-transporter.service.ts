import { LogEventInterface } from "@common/interfaces/log-event.interface";
import { ServiceBusTopicInterface } from "@common/interfaces/serviceBusTopic.interface";
import * as config from "@config/index";
import { Injectable } from "@nestjs/common";
import { AppLogTransformerService } from "./app-log-transformer.service";
import { LogTransporterService } from "./log-transporter.service";

@Injectable()
export class AppLogTransporterService {

    private topicLogging: ServiceBusTopicInterface;

    /**
     * AppLogTransporterService constructor
     * 
     * @param transporter 
     * @param logTransformer 
     */
    constructor(
        private readonly transporter: LogTransporterService,
        private readonly logTransformer: AppLogTransformerService,
    ) {
        this.topicLogging = config.default.serviceBus.topicLogging;
    }

    /**
     * Log information to transporter 
     * 
     * @param message 
     * @param originalMessage 
     */
    async info(message: LogEventInterface, originalMessage?: Record<string, any>) {

        await this.transporter.sendMessage(
            this.topicLogging,
            await this.logTransformer.transformSuccessLog(message, originalMessage)
        )
    }

    /**
     * Log errors to transporter 
     * 
     * @param message 
     * @param err 
     * @param originalMessage 
     */
    async error(message: LogEventInterface, err: any, originalMessage?: Record<string, any>) {

        await this.transporter.sendMessage(
            this.topicLogging,
            await this.logTransformer.transformErrorLog(message, err, originalMessage)
        )
    }
}
