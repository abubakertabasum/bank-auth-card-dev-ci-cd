import { LogLevel } from "@common/constants/log-level.enum";
import { LogEventInterface } from "@common/interfaces/log-event.interface";
import * as config from "@config/index";
import { HttpException, Inject } from "@nestjs/common";
import { REQUEST } from "@nestjs/core";
import { uniqueID } from "@utils/helpers";

export class AppLogTransformerService {

    constructor(@Inject(REQUEST) private request) { }

    async transform(message: LogEventInterface, err?: HttpException) {

        if (err instanceof HttpException) {
            const errorMessage = await this.transformErrorLog(message, err);

            return errorMessage;
        }

        const successLog = await this.transformSuccessLog(message);

        return successLog;
    }

    async transformSuccessLog(message: LogEventInterface, originalMessage?: Record<string, any>) {
        const timestamp = new Date().toISOString();
        const formattedLog = {
            LogID: await uniqueID(),
            TraceID: this.request.headers?.request_trace_id,
            What: {
                ParamCode: message.paramCode,
                OrigMessage: originalMessage,
                Message: message.name,
                Severity: LogLevel.INFO,
                Tags: message.tags,
            },
            Who: {
                UID: this.request?.user?.idx,
                Session: '',
                Request: this.request?.originalUrl
            },
            Where: {
                Service: config.default.appName,
                ContainerName: process.domain,
                Hostname: this.request.host,
                PID: process.pid,
            },
            When: {
                Timestamp: timestamp
            }
        }

        return formattedLog;
    }

    async transformErrorLog(message: LogEventInterface, err: HttpException, originalMessage?: Record<string, any>) {
        const timestamp = new Date().toISOString();
        const origMessage = { ...err, ...originalMessage };
        const formattedLog = {
            LogID: await uniqueID(),
            TraceID: this.request.headers?.request_trace_id,
            What: {
                ParamCode: message.paramCode,
                OrigMessage: origMessage,
                Message: message.name,
                Severity: LogLevel.ERROR,
                Tags: message.tags,
            },
            Who: {
                UID: this.request?.user?.idx,
                Session: '',
                Request: this.request?.originalUrl
            },
            Where: {
                Service: config.default.appName,
                ContainerName: '',
                Hostname: this.request.hostname,
                PID: process.pid,
            },
            When: {
                Timestamp: timestamp
            }
        }

        return formattedLog;
    }
}
