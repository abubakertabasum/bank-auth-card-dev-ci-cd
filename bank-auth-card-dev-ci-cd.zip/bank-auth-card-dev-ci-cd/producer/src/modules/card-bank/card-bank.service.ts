import {
	CACHE_MANAGER,
	HttpException,
	HttpStatus,
	Inject,
	Injectable,
	Logger,
} from '@nestjs/common';
import { Customer } from '@entities/Customer.entity';
import { Bank } from '@entities/Bank.entity';
import { EmployeeCardInfoRepository } from './card.repository';
import { customAlphabet } from 'nanoid/async';
import { DEBIT_CARD_REQUEST_PAYLOAD } from '@common/constants/notification.payload';
import { sendNotification } from '@utils/azureBus.helper';
import { CardDto } from '@dtos/CardDto';
import * as moment from 'moment';
import * as config from '../../config/index';
import { TabapayApiClient } from '../card-bank/tabapay.api.client';
import { ServiceBusSenderService } from '@modules/service-bus-sender/service-bus-sender.service';
import { TestEditDto } from '@dtos/testEditCard.dto';
import { EmployeeNewCardInfoEntity } from '@entities/EmployeeNewCardInfo.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between, getConnection, In, getRepository, Brackets, Not } from 'typeorm';
import { NewCardDto } from '@dtos/NewCardDto';
import { EditCardDto } from '@dtos/editCardDto';
import { v4 as uuid } from 'uuid';
import { EditCardParamsDto } from '@dtos/EditNickName.dto';
import { CheckCardVender } from '@dtos/CheckCardVender.dto';
import { AppLogTransporterService } from '@modules/app-log-transporter/app-log-transporter.service';
import { ABLE_TO_REMOVE_THE_CARD_SUCCESSFULLY, CARD_ADDED_SUCCESSFULLY, CARD_UPDATED_SUCCESSFULLY, UNABLE_TO_ADD_CARD, UNABLE_TO_REMOVE_CARDS, UNABLE_TO_UPDATE_THE_CARD } from '@common/constants/employee-operations.events';

// Service Bus Connection String
const connectionStringTopic = config.default.sbSenderConnectionStringTopic;
// Max Retries
const maxRetries = config.default.sbSenderMaxRetries;
const REQUEST_APPROVE_SUCCESS_MSG = 'Request Approved Successfully';
const topicName = config.default.topicName;

@Injectable()
export class CardBankService {
	private readonly nanoid = customAlphabet('1234567890', 6);
	constructor(
		private cardInfoRepository: EmployeeCardInfoRepository,
		private tabapayApiClient: TabapayApiClient,
		private readonly serviceBusService: ServiceBusSenderService,
		@InjectRepository(EmployeeNewCardInfoEntity)
		private readonly employeeNewCardInfoRepo: Repository<EmployeeNewCardInfoEntity>,
		private readonly appLogTransporterService: AppLogTransporterService
	) { }

	async getEmployeeCard(user: Customer) {
		const carInfoFound = this.employeeNewCardInfoRepo.find({
			where: {
				customer: user.id,
				is_obsolete: false,
			}
		});
		let resultArray = [];
		if (carInfoFound) {
			(await carInfoFound).forEach(async card_info => {
				const obj = {};
				const keys_to_keep = ['idx', 'card_number', 'expiry_date', 'cvv', 'type', 'is_primary', 'nick_name', 'card_type', 'card_logo_url'];
				let checkVendor: CheckCardVender = { card_number: card_info.card_number }
				const cardVendorResponse = await this.checkCardVender(checkVendor);
				card_info['card_type'] = cardVendorResponse.type;
				card_info['card_logo_url'] = cardVendorResponse.url;
				keys_to_keep.forEach(key => obj[key] = card_info[key]);
				resultArray.push(obj);
				resultArray = resultArray.sort(function (a, b) {
					return b.is_primary - a.is_primary
				})
			});
		}
		return resultArray;
	}

  async getEmployeeCardBalance(user: Customer){
	const bankRepository = getRepository(Bank);
	console.log('card balance');
	const bank = await bankRepository.findOne({
	  where: {
		account_number: user.card_infos[0].card_number
	  }
	});
	return bank.account_balance;    //Check this with Rohit/Jenish
  }

	async createEmployeeCard(user: Customer, data: NewCardDto) {
		const { employee_id } = user;
		const existingCardList = [];
		const dateMomentObject = moment(data.expiry_date.replace('/', '/20'), 'MM/YYYY');
		const accountInfo = {
			"bank_info": null
		};
		const currentBankService = config.default.bankServiceType;
		console.log("Currently Active Bank Environment =>" + currentBankService);
		switch (currentBankService) {
			case 'MX':
				//   if (user.bank_infos.length === 0) {
				// 	throw new HttpException('No bank linked with the user', HttpStatus.BAD_REQUEST);
				//   }
				let bankInfos = [];
				try {
					bankInfos = user?.bank_infos.map(bank_info => {
						const obj = {};
						const keys_to_keep = ['bank_name', 'account', 'account_id', 'routing', 'wire_routing'];
						if (bank_info.is_obsolete !== true) {
							keys_to_keep.forEach(key => obj[key] = bank_info[key]);
						}
						return obj;
					});

				} catch (error) {
					console.log("User Bank Info not Found For ==>" + user);
				}

				if (bankInfos.length) {
					accountInfo.bank_info = bankInfos[0];
				} else {
					accountInfo.bank_info = {};
				}
				console.log("MX Bank Info Taken");
				break;

			case 'PLAID':
				//   if (user.plaid_infos.length === 0) {
				// 	throw new HttpException('No bank linked with the user', HttpStatus.BAD_REQUEST);
				//   }
				let plaidInfos = [];
				try {
					plaidInfos = user?.plaid_infos.map(plaid_info => {
						const obj = {};
						const keys_to_keep = ['bank_name', 'account', 'account_id', 'routing', 'wire_routing'];

						if (plaid_info.is_obsolete !== true) {

							keys_to_keep.forEach(key => obj[key] = plaid_info[key]);
						}

						return obj;
					});
				} catch (error) {
					console.log("User Plaid Info not Found For ==>" + user);
				}

				if (plaidInfos.length > 0) {
					accountInfo.bank_info = plaidInfos[0];
				} else {
					accountInfo.bank_info = {};
				}
				console.log("Plaid Bank Info Taken");
				break;

			default:
				console.log("No Active Bank Enviroment Found");
				break;
		}
		if (dateMomentObject.toDate() < moment().toDate()) {
			const cardExpiredException = new HttpException(
				`Your card has already been expired`,
				HttpStatus.BAD_REQUEST
			);
			await this.appLogTransporterService.error(
				UNABLE_TO_ADD_CARD,
				cardExpiredException
			)
			throw cardExpiredException;
		}


		const foundCardInfo = await getConnection()
			.getRepository(EmployeeNewCardInfoEntity)
			.find({
				where: {
					is_obsolete: false,
					customer: user.id,
				},
				select: [
					'card_number',
				],
			}).then(cardInfos => {
				cardInfos.map(data => {
					existingCardList.push(data.card_number)
				})
			});

		if (existingCardList.includes(data.card_number)) {
			const cardAlreadyExistException = new HttpException(
				'Card already exists in your Bucket',
				HttpStatus.BAD_REQUEST
			);
			await this.appLogTransporterService.error(
				UNABLE_TO_ADD_CARD,
				cardAlreadyExistException
			)
			throw cardAlreadyExistException;
		}
		console.log("******************************************Validation Crossed**********************************************");

		// await this.cardInfoRepository
		//   .createQueryBuilder('EmployeeCardInfo')
		//   .leftJoinAndSelect('EmployeeCardInfo.customer', 'customer')
		//   .where('customer.employer_id = :employer_id', { employer_id })
		//   .select('EmployeeCardInfo.card_number')
		//   .getMany()
		//   .then(cardInfos => {
		// 	cardInfos.map( data => {
		// 	  existingCardList.push(data.card_number)
		// 	})
		//   });
		// console.log("*************************************Card add - Existing cards query result ------------------------------>"+ JSON.stringify(existingCardList));
		// if (existingCardList.includes(data.card_number)){
		//   throw new HttpException(
		// 	'Card already exists for another employee',
		// 	HttpStatus.BAD_REQUEST,
		//   );
		// }

		// Let's prepare object for query
		const cardDto: CardDto = {
			card_number: data.card_number,
			expiry_date: data.expiry_date,
			cvv: data.cvv,
			type: data.type
		};

		const queryCardResponse = await this.tabapayApiClient.queryCard(cardDto);
		Logger.log('************Query Card response ***');
		Logger.log(queryCardResponse);
		Logger.log('************Query Card response ***');
		console.log("*************************************Tabapay Response for query Card ------------------------------>" + JSON.stringify(queryCardResponse));

		if (!(queryCardResponse.SC === 200)) {
			const invalidCardException = new HttpException({
				message: 'Invalid card',
				messageCode: {
					SC: queryCardResponse?.SC,
					NetworkRC: queryCardResponse?.NetworkRC
				}
			}, HttpStatus.BAD_REQUEST)
			await this.appLogTransporterService.error(
				UNABLE_TO_ADD_CARD,
				invalidCardException
			)
			throw invalidCardException;
		} else {

			const createAccountResponse = await this.tabapayApiClient.createAccount(user, cardDto);
			console.log("*************************************Tabapay Response for create Card ------------------------------>" + JSON.stringify(createAccountResponse));

			if (createAccountResponse.SC === 409) {
				const cardAlreadyBeenUsedException = new HttpException(
					'Card has already been used earlier',
					HttpStatus.BAD_REQUEST,
				);
				await this.appLogTransporterService.error(
					UNABLE_TO_ADD_CARD,
					cardAlreadyBeenUsedException
				);
				throw cardAlreadyBeenUsedException;
			} else if (createAccountResponse.SC === 200) {
				const createdIdx: string = uuid();
				// Defualt Card Check
				if (!data.is_primary) {
					const userCardInfo = await this.getEmployeeCard(user);
					if (userCardInfo.length <= 0) {
						data.is_primary = true;
						console.log("It's a Default Card *************************************************");
					}
				}
				const { serviceBusDto, cardInfo } = this.cardInfoRepository.createEmployeeCardInfo(
					user, data, createAccountResponse.accountID, createdIdx, true
				);

				//   DEBIT_CARD_REQUEST_PAYLOAD['employee_idx'] = user.idx;
				//   DEBIT_CARD_REQUEST_PAYLOAD['data'] = [
				// 	{
				// 	  'key': 'employee_name',
				// 	  'value': `${user.first_name}${user.middle_name ? ' ' + user.middle_name + ' ' : ' '}${user.last_name}`
				// 	}];

				//   sendNotification(DEBIT_CARD_REQUEST_PAYLOAD);
				await this.serviceBusService.sendMessage(topicName, serviceBusDto);

				// this.notificationBuilder(user);

				const successPayload = {
					idx: createdIdx,
					bank_name: accountInfo?.bank_info?.bank_name ? accountInfo?.bank_info?.bank_name : "",
					account_number: accountInfo?.bank_info?.account ? accountInfo?.bank_info?.account : "",
					card_number: cardInfo.card_number,
					expiry_date: cardInfo.expiry_date,
					// cvv: cardInfo.cvv,
					type: cardInfo.type,
					is_primary: cardInfo.is_primary,
					nick_name: cardInfo.nick_name
				};

				await this.appLogTransporterService.info(
					CARD_ADDED_SUCCESSFULLY,
					successPayload
				);

				return successPayload;

			} else {
				const cardValidationException = new HttpException(
					'There was a problem validating the card',
					HttpStatus.BAD_REQUEST,
				);
				await this.appLogTransporterService.error(
					UNABLE_TO_ADD_CARD,
					cardValidationException
				);

				throw cardValidationException;
			}

		}
	}

	async editEmployeeCard(user: Customer, data: EditCardDto) {
		const dateMomentObject = moment(data.expiry_date.replace('/', '/20'), 'MM/YYYY');
		const { employer_id } = user;
		const existingCardList = [];
		const accountInfo = {
			"bank_info": null
		};
		const currentBankService = config.default.bankServiceType;
		console.log("Currently Active Bank Enviroment =>" + currentBankService);
		switch (currentBankService) {
			case 'MX':
				//   if (user.bank_infos.length === 0) {
				// 	throw new HttpException('No bank linked with the user', HttpStatus.BAD_REQUEST);
				//   }
				let bankInfos = [];
				try {
					bankInfos = user?.bank_infos.map(bank_info => {
						const obj = {};
						const keys_to_keep = ['bank_name', 'account', 'account_id', 'routing', 'wire_routing'];
						if (bank_info.is_obsolete !== true) {
							keys_to_keep.forEach(key => obj[key] = bank_info[key]);
						}
						return obj;
					});

				} catch (error) {
					console.log("User Bank Info not Found For ==>" + user);
				}

				if (bankInfos.length > 0) {
					accountInfo.bank_info = bankInfos[0];
				} else {
					accountInfo.bank_info = {};
				}
				console.log("MX Bank Info Taken");
				break;

			case 'PLAID':
				//   if (user.plaid_infos.length === 0) {
				// 	throw new HttpException('No bank linked with the user', HttpStatus.BAD_REQUEST);
				//   }

				let plaidInfos = [];
				try {
					plaidInfos = user?.plaid_infos.map(plaid_info => {
						const obj = {};
						const keys_to_keep = ['bank_name', 'account', 'account_id', 'routing', 'wire_routing'];
						if (plaid_info.is_obsolete !== true) {

							keys_to_keep.forEach(key => obj[key] = plaid_info[key]);
						}
						return obj;
					});
				} catch (error) {
					console.log("User Plaid Info not Found For ==>" + user);
				}

				if (plaidInfos.length > 0) {
					accountInfo.bank_info = plaidInfos[0];
				} else {
					accountInfo.bank_info = {};
				}
				console.log("Plaid Bank Info Taken");
				break;

			default:
				console.log("No Active Bank Enviroment Found");
				break;
		}

		if (dateMomentObject.toDate() < moment().toDate()) {
			const cardExpiredException = new HttpException(
				`Your card has already been expired`,
				HttpStatus.BAD_REQUEST
			);
			await this.appLogTransporterService.error(
				UNABLE_TO_UPDATE_THE_CARD,
				cardExpiredException
			)
			throw cardExpiredException;
		}
		const cardInfoFound = await this.employeeNewCardInfoRepo.findOne({
			where: {
				idx: data.card_idx,
				is_obsolete: false,
				customer: user.id
			}
		});
		console.log("*************************************Card Info Found are in edit ------------------------------>" + JSON.stringify(cardInfoFound));
		if (!cardInfoFound) {
			const cardNotFoundException = new HttpException(
				'Card Not Found!',
				HttpStatus.BAD_REQUEST
			);
			await this.appLogTransporterService.error(
				UNABLE_TO_UPDATE_THE_CARD,
				cardNotFoundException
			)
			throw cardNotFoundException;
		}

		await getConnection()
			.getRepository(EmployeeNewCardInfoEntity)
			.find({
				where: {
					is_obsolete: false,
					customer: user.id,
				},
			}).then(cardInfos => {
				cardInfos.map(data => {
					existingCardList.push(data);
				})
			});
		console.log("Existing data ==========================================>" + JSON.stringify(existingCardList));
		if (existingCardList.length > 0) {
			for await (const iterator of existingCardList) {
				if (iterator.idx !== data.card_idx && iterator.card_number == data.card_number) {

					const cardAlreadyExistException = new HttpException(
						'Same Card already exists in your Bucket',
						HttpStatus.BAD_REQUEST
					);
					await this.appLogTransporterService.error(
						UNABLE_TO_UPDATE_THE_CARD,
						cardAlreadyExistException
					)
					throw cardAlreadyExistException;
				}
			}
		}



		// Let's prepare object for query
		const cardDto: CardDto = {
			card_number: data.card_number,
			expiry_date: data.expiry_date,
			cvv: data.cvv,
			type: data.type
		};
		const queryCardResponse = await this.tabapayApiClient.queryCard(cardDto);


		Logger.log('************Query Card response ***');
		Logger.log(queryCardResponse);
		Logger.log('************Query Card response ***');
		console.log("*************************************Tabapay Response for query Card ------------------------------>" + JSON.stringify(queryCardResponse));

		if (!(queryCardResponse.SC === 200)) {
			const invalidCardException = new HttpException({
				message: 'Invalid card',
				messageCode: {
					SC: queryCardResponse?.SC,
					NetworkRC: queryCardResponse?.NetworkRC
				}
			}, HttpStatus.BAD_REQUEST)
			await this.appLogTransporterService.error(
				UNABLE_TO_UPDATE_THE_CARD,
				invalidCardException
			)
			throw invalidCardException;
		} else {

			const createAccountResponse = await this.tabapayApiClient.createAccount(user, data);

			console.log("*************************************Tabapay Response for edit Card ------------------------------>" + JSON.stringify(createAccountResponse));

			if (createAccountResponse.SC === 409) {
				throw new HttpException(
					'Card has already been used earlier',
					HttpStatus.BAD_REQUEST,
				);
			} else if (createAccountResponse.SC === 200) {
				// Default Card Check
				if (!data.is_primary) {
					const userCardInfo = await this.getEmployeeCard(user);
					if (userCardInfo.length <= 0) {
						data.is_primary = true;
						console.log("It's a Default Card *************************************************");
					}
				}
				const { serviceBusDto, cardInfo } = this.cardInfoRepository.createEmployeeCardInfo(
					user, data, createAccountResponse.accountID, data.card_idx, false);
				console.log('Going to card add with DTO -> ' + JSON.stringify(serviceBusDto));
				await this.serviceBusService.sendMessage(topicName, serviceBusDto);
				// this.notificationBuilder(user);

				const successPayload = {
					idx: data.card_idx,
					bank_name: accountInfo?.bank_info?.bank_name ? accountInfo?.bank_info?.bank_name : "",
					account_number: accountInfo?.bank_info?.account ? accountInfo?.bank_info?.account : "",
					card_number: cardInfo.card_number,
					expiry_date: cardInfo.expiry_date,
					// cvv: cardInfo.cvv,
					type: cardInfo.type,
					is_primary: cardInfo.is_primary,
					nick_name: cardInfo.nick_name
				};

				await this.appLogTransporterService.info(
					CARD_UPDATED_SUCCESSFULLY,
					successPayload
				);

				return successPayload;
			} else {
				const cardValidationException = new HttpException(
					'There was a problem validating the card',
					HttpStatus.BAD_REQUEST,
				);
				await this.appLogTransporterService.error(
					UNABLE_TO_UPDATE_THE_CARD,
					cardValidationException
				);

				throw cardValidationException;
			}
		}
	}

	async getEmployeAllCards(user: Customer) {
		return user.card_infos.map(card_info => {
			const obj = {};
			const keys_to_keep = ['card_number', 'expiry_date', 'cvv', 'type'];

			keys_to_keep.forEach(key => obj[key] = card_info[key]);

			return obj;
		});
	}


	async notificationBuilder(user: Customer) {
		DEBIT_CARD_REQUEST_PAYLOAD['employee_idx'] = user.idx;
		DEBIT_CARD_REQUEST_PAYLOAD['data'] = [
			{
				'key': 'employee_name',
				'value': `${user.first_name}${user.middle_name ? ' ' + user.middle_name + ' ' : ' '}${user.last_name}`
			}];

		sendNotification(DEBIT_CARD_REQUEST_PAYLOAD);
	}

	async editNickName(user: Customer, data: EditCardParamsDto) {
		const cardInfoFound = await this.employeeNewCardInfoRepo.findOne({
			where: {
				idx: data.card_idx,
				is_obsolete: false,
				customer: user.id
			}
		});
		console.log("*************************************Card Info Found are in edit nick name------------------------------>" + JSON.stringify(cardInfoFound));
		if (!cardInfoFound) {
			throw new HttpException(
				'Card Not Found!',
				HttpStatus.BAD_REQUEST,
			);
		}
		let nickName = '';
		if (data.nick_name) {
			nickName = data.nick_name;
		}
		const serviceBusBodyDto = {
			cardIdx: data.card_idx,
			nickName: nickName
		}

		const serviceBusDto = {
			serviceType: 'bank-edit-card-info-nick-name',
			body: serviceBusBodyDto,
		};
		await this.serviceBusService.sendMessage(topicName, serviceBusDto);
		return { statusCode: 200, message: 'Operation successful' };

	}

	async changeToPrimary(user: Customer, data: EditCardParamsDto) {
		const cardInfoFound = await this.employeeNewCardInfoRepo.findOne({
			where: {
				idx: data.card_idx,
				is_obsolete: false,
				customer: user.id
			}
		});
		console.log("*************************************Card Info Found are in change to primary ------------------------------>" + JSON.stringify(cardInfoFound));
		if (!cardInfoFound) {
			throw new HttpException(
				'Card Not Found!',
				HttpStatus.BAD_REQUEST,
			);
		}
		const serviceBusBodyDto = {
			cardIdx: data.card_idx,
			employee: user
		}

		const serviceBusDto = {
			serviceType: 'bank-edit-card-info-change-to-primary',
			body: serviceBusBodyDto,
		};
		await this.serviceBusService.sendMessage(topicName, serviceBusDto);
		return { statusCode: 200, message: 'Operation successful' };

	}

	async generateNewKey() {
		const response = await this.tabapayApiClient.generateNewKey();
		return response;
	}
	async deletExitingCard(user: Customer, data: EditCardParamsDto) {
		const cardInfoFound = await this.employeeNewCardInfoRepo.findOne({
			where: {
				idx: data.card_idx,
				is_obsolete: false,
				customer: user.id
			}
		});
		console.log("*************************************Card Info Found are in Delete ------------------------------>" + JSON.stringify(cardInfoFound));
		if (!cardInfoFound) {
			const cardNotFoundException = new HttpException(
				'Card Not Found!',
				HttpStatus.BAD_REQUEST
			);
			await this.appLogTransporterService.error(
				UNABLE_TO_REMOVE_CARDS,
				cardNotFoundException
			)
			throw cardNotFoundException;
		}
		const serviceBusBodyDto = {
			cardIdx: data.card_idx,
		}

		if(cardInfoFound.is_primary){
			const canidateCardForPrimary = await this.employeeNewCardInfoRepo.findOne({
				where: {
					is_obsolete: false,
					customer: user.id,
					idx:Not(data.card_idx)
				},
				order:{created_on:'ASC'}
			})
			if(!canidateCardForPrimary){
				throw new HttpException(
					'there is no card to make primary',
					HttpStatus.BAD_REQUEST
				)
			}
			const serviceBusBodyDto = {
				cardIdx: canidateCardForPrimary.idx,
				employee: user
			  }
		
			  const serviceBusDto = {
				serviceType: 'bank-edit-card-info-change-to-primary',
				body: serviceBusBodyDto,
			  };
			await this.serviceBusService.sendMessage(topicName, serviceBusDto);
		}
		// const createAccountResponse = await this.tabapayApiClient.deleteAccount(user, cardInfoFound.tabapay_account_id);

		// if (createAccountResponse.SC === 409) {
		// 	throw new HttpException(
		// 		'Conflicting Request Parameters',
		// 		HttpStatus.BAD_REQUEST,
		// 	);
		// } else if (createAccountResponse.SC === 200) {

		// 	const serviceBusDto = {
		// 		serviceType: 'bank-delete-card-info',
		// 		body: serviceBusBodyDto,
		// 	};
		// 	await this.serviceBusService.sendMessage(topicName, serviceBusDto);
		// 	return { statusCode: 200, message: 'Operation successful' };

		// } else {
		// 	throw new HttpException(
		// 		'There was a problem validating the card',
		// 		HttpStatus.BAD_REQUEST,
		// 	);
		// }
		const serviceBusDto = {
			serviceType: 'bank-delete-card-info',
			body: serviceBusBodyDto,
		};
		await this.serviceBusService.sendMessage(topicName, serviceBusDto);
		await this.appLogTransporterService.info(ABLE_TO_REMOVE_THE_CARD_SUCCESSFULLY);

		return { statusCode: 200, message: 'Operation successful' };
	}

	async checkCardVender(cardNumber: CheckCardVender,): Promise<any> {
		var visa = new RegExp("^4[0-9]{12}(?:[0-9]{3})?$");
		// var amex = new RegExp("^3[47][0-9]{13}$");
		var mastercard = new RegExp("^5[1-5][0-9]{14}$");
		if (visa.test(cardNumber.card_number)) {
			console.log("It's a Visa Card");
			return { type: "VISA", url: config.default.minio.fileServer + 'orbis/Visa.png' }
		} else if (mastercard.test(cardNumber.card_number)) {
			console.log("It's a MASTER Card");
			return { type: "MASTERCARD", url: config.default.minio.fileServer + 'orbis/Mastercard.png' }
		}
		throw new HttpException(
			'Invalid Card!',
			HttpStatus.BAD_REQUEST,
		);
	}
}
