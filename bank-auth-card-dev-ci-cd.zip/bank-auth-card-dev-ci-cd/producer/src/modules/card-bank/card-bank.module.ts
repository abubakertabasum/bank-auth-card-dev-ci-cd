import { Module } from '@nestjs/common';
import { CardBankService } from './card-bank.service';
import { CardBankController } from './card-bank.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceBusSenderModule } from '@modules/service-bus-sender/service-bus-sender.module';
import { Customer } from '@entities/Customer.entity';
import { ActivityLog} from '@entities/ActivityLog.entity';
import { Protocol } from '@entities/Protocol.entity';
import { EmployeeCardInfoRepository } from './card.repository';
import { EmployeeNewCardInfoEntity } from '@entities/EmployeeNewCardInfo.entity';
import { TabapayApiClient } from './tabapay.api.client';
import { TokenModule } from '@modules/token/token.module';
import { AppLogTransporterModule } from '@modules/app-log-transporter/app-log-transporter.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Customer,
      Protocol,
      ActivityLog,
      EmployeeCardInfoRepository,
      EmployeeNewCardInfoEntity
    ]),
    ServiceBusSenderModule,
    AppLogTransporterModule,
    TokenModule
  ],
  providers: [CardBankService, TabapayApiClient],
  controllers: [CardBankController],
})
export class CardBankModule {}
