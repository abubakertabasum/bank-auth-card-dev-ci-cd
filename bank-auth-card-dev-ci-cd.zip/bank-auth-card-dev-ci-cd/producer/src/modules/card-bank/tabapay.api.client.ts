import { Injectable } from '@nestjs/common';

import { CardDto } from '../../dtos/CardDto'
import { Customer } from '../../entities/Customer.entity';
import { getRandomNumber } from '../../utils/helpers';
import axios from 'axios';
import * as querystring from 'querystring';
import { TabapayLogger } from '../../common/logger/logger';

const TABAPAY_REQUEST_URL = querystring.unescape(process.env.TABAPAY_REQUEST_URL);
const TABAPAY_ENCRYPT_URL = querystring.unescape(process.env.TABAPAY_ENCRYPT_URL);

@Injectable()
export class TabapayApiClient {
	private readonly tabapayLogger = new TabapayLogger('TabapayLogs');

  toRequestDate(dateString){
      return `20${dateString.split('/')[1]}${dateString.split('/')[0]}`
  }

  async getEncryptedCard(cardDto: CardDto, accountEncryption= false): Promise<any>{
    const requestData = {
      encrypt_string: `${cardDto.card_number}|${this.toRequestDate(cardDto.expiry_date)}|${cardDto.cvv}`
      // encrypt_string: accountEncryption ? `${cardDto.card_number}|${this.toRequestDate(cardDto.expiry_date)}` : `${cardDto.card_number}|${this.toRequestDate(cardDto.expiry_date)}|${cardDto.cvv}`
    };
    try {
      const response = await axios({
        method: 'post',
        url: TABAPAY_ENCRYPT_URL,
        data: requestData,
        headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
      });
      return response.data.rsa;
    } catch(e) {
      console.log('***************');
      console.log(e);
    }
  }

  async generateNewKey(): Promise<any> {
    const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/keys`;
    console.log("Tabapay Request URL(Get new key) ------>" + requestUrl);
    const requestData = 
       {
         "format": "ASN.1",
         "expiration": 365
       };
       //const requestData = {
       // "format": "Raw",
       // "expiration": 365
       // };
    const response = await axios({
       method: 'post',
       url: requestUrl,
       data: requestData,
       headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
     })
      .then(response => {
        console.log('*********************Response is **********************');
        console.log(JSON.stringify(response.data));
        return response.data
      })
      .catch(error => {
        this.tabapayLogger.log(`Request For Key create: \n ${JSON.stringify(requestData)} \n Response for key create: \n ${JSON.stringify(error.response.data)} `);

        return error.response.data
    });
  }

  async queryCard(cardDto: CardDto): Promise<any> {
    const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/cards`;
    console.log("Tabapay Request URL(Get query card) ------>" + requestUrl);
    const requestData = {
          card: {
            keyID: process.env.TABAPAY_KEY_ID,
            data: await this.getEncryptedCard(cardDto)
        }
      };
    const response = await axios({
       method: 'post',
       url: requestUrl,
       data: requestData,
       headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
     })
      .then(response => {
        return response.data
      })
      .catch(error => {
        this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(error.response.data)} `);

        return error.response.data
    });

    try {
      this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(response)} `)
    }catch (e) {}

    return response
    }

  async createAccount(user: Customer, cardDto: CardDto): Promise<any> {
    // const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/accounts?RejectDuplicateCard`;
    const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/accounts`;
    console.log("Tabapay Request URL(Post Create Account) ------>" + requestUrl);
    const requestData = {
        referenceID: getRandomNumber(15),
        card: {
            keyID: process.env.TABAPAY_KEY_ID,
            data: await this.getEncryptedCard(cardDto, true)
        },
        owner: {
          name: {
            first: user.first_name,
            last: user.last_name
          }
        }
      };

    const response = await axios({
       method: 'post',
       url: requestUrl,
       data: requestData,
       headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
     })
      .then(response => {
        return response.data
      })
      .catch(error => {
        this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(error.response.data)} `);

        return error.response.data
    });

    try {
      this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(response)} `)
    }catch (e) {}

    return response
  }

  async createSenderAccount(): Promise<any> {
    const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/accounts`;
    const requestData = {
        referenceID: getRandomNumber(15),
        bank: {
            accountNumber: process.env.TABAPAY_SENDER_ACCOUNT_NUMBER,
            routingNumber: process.env.TABAPAY_SENDER_ROUTING_NUMBER,
            accountType: process.env.TABAPAY_SENDER_ACCOUNT_ACCOUNT_TYPE
        },
        owner: {
          name: {
            first: process.env.TABAPAY_SENDER_FIRST_NAME,
            last: process.env.TABAPAY_SENDER_LAST_NAME
          }
        }
      };
    const response = await axios({
       method: 'post',
       url: requestUrl,
       data: requestData,
       headers: {
         'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}`,
         'Content-Type': 'application/json'
       }
     })
      .then(response => {
        return response.data
      })
      .catch(error => {
        this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(error.response.data)} `);

        return error.response.data
    });

    try {
      this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(response)} `)
    }catch (e) {}

    return response
  }

  async createTransaction(sourceAccountId, destinationAccountId, amount): Promise<any> {
    const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/transactions`;
    const requestData = {
          referenceID: getRandomNumber(15),
          type: 'push',
          accounts:
          {
            sourceAccountID: sourceAccountId,
            destinationAccountID: destinationAccountId
          },
          amount: String(parseFloat(amount).toFixed(2))
        };

     const response = await axios({
       method: 'post',
       url: requestUrl,
       data: requestData,
       headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
     })
       .then(response => {
        return response.data
      })
       .catch(error => {
        this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(error.response.data)} `);

        return error.response
    });

    try {
      this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestData)} \n Response: \n ${JSON.stringify(response)} `)
    }catch (e) {}

    return response
    }

    async deleteAccount(user: Customer, tabpayAccountId: string): Promise<any> {
      // const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/accounts?RejectDuplicateCard`;
      const accountId = tabpayAccountId;
      const requestUrl = `${TABAPAY_REQUEST_URL}/v1/clients/${process.env.TABAPAY_CLIENT_ID}/accounts/${accountId}`;
      console.log("Tabapay Request URL(Delete Account) ------>" + requestUrl);
      const response = await axios({
         method: 'delete',
         url: requestUrl,
        //  data: requestData,
         headers: { 'Authorization': `Bearer ${process.env.TABAPAY_ACCESS_TOKEN}` }
       })
        .then(response => {
          return response.data
        })
        .catch(error => {
          this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestUrl)} \n Response: \n ${JSON.stringify(error.response.data)} `);
  
          return error.response.data
      });
  
      try {
        this.tabapayLogger.log(`Request: \n ${JSON.stringify(requestUrl)} \n Response: \n ${JSON.stringify(response)} `)
      }catch (e) {}
  
      return response
    }
}
