import { Body, Controller, Get, Post, UseGuards, UsePipes, ValidationPipe } from '@nestjs/common';
import { GetUser } from '../../common/GetUser';
import { Customer } from '@entities/Customer.entity';
import { CardDto } from '@dtos/CardDto';
import { JwtAuthGuard } from '../../common/JwtGuard';
import { CardBankService } from './card-bank.service';
import { TestEditDto } from '@dtos/testEditCard.dto';
import { NewCardDto } from '@dtos/NewCardDto';
import { EditCardDto } from '@dtos/editCardDto';
import { EditCardParamsDto } from '@dtos/EditNickName.dto';
import { CheckCardVender } from '@dtos/CheckCardVender.dto';

@Controller('card-bank')
export class CardBankController {
  constructor(private readonly cardBankService: CardBankService,) {}
  @UseGuards(JwtAuthGuard)
  @Get('card/')
  async getEmployeeCards(
    @GetUser() user: Customer){
    return await this.cardBankService.getEmployeeCard(user);
  }

  @UseGuards(JwtAuthGuard)
  @Get('card/balance')
  async getEmployeeCardBalance(
    @GetUser() user: Customer){
    return await this.cardBankService.getEmployeeCardBalance(user);
  }

  @UseGuards(JwtAuthGuard)
  @UsePipes(new ValidationPipe({ validationError: { target: false } }))
  @Post('card/create/')
  async createEmployeeCard(
    @Body() data: NewCardDto,
    @GetUser() user: Customer){
    return await this.cardBankService.createEmployeeCard(user, data);
  }

  /**
   * @param {CardDto} cardData
   * @returns 
   */
   @UseGuards(JwtAuthGuard)
   @UsePipes(new ValidationPipe({ validationError: { target: false } }))
   @Post('card/edit/')
   async editEmployeeCard(
     @Body() cardData: EditCardDto,
     @GetUser() user: Customer){
     return await this.cardBankService.editEmployeeCard(user, cardData);
   }

     /**
   * @param {TestEditDto} testData
   * @returns 
   */
      // @UseGuards(JwtAuthGuard)
      // @UsePipes(new ValidationPipe({ validationError: { target: false } }))
      // @Post('card/test-edit/')
      // async testEditEmployeeCard(
      //   @Body() testData: TestEditDto,
      //   @GetUser() user: Customer){
      //   return await this.cardBankService.testEditEmployeeCard(user, testData);
      // }
 
    /**
   * @param {CardDto} cardData
   * @returns 
   */
   @UseGuards(JwtAuthGuard)
   @UsePipes(new ValidationPipe({ validationError: { target: false } }))
   @Post('card/edit/nick-name')
   async editNickName(
     @Body() editNickNameDto: EditCardParamsDto ,
     @GetUser() user: Customer){
     return await this.cardBankService.editNickName(user, editNickNameDto);
   }
  /**
  * @param {CardDto} cardData
  * @returns 
  */
  @UseGuards(JwtAuthGuard)
  @UsePipes(new ValidationPipe({ validationError: { target: false } }))
  @Post('card/edit/change-to-primary')
  async changePrimary(
    @Body() editNickNameDto: EditCardParamsDto,
    @GetUser() user: Customer) {
    return await this.cardBankService.changeToPrimary(user, editNickNameDto);
  }

   /**
  * @param {CardDto} cardData
  * @returns 
  */
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe({ validationError: { target: false } }))
    @Post('card/delete/')
    async deleteExistingCard(
      @Body() editNickNameDto: EditCardParamsDto,
      @GetUser() user: Customer) {
      return await this.cardBankService.deletExitingCard(user, editNickNameDto);
    }
  
  /**
   * 
   * @param checkCardVender 
   * @returns 
   */
  @UseGuards(JwtAuthGuard)
  @Post('card/check-card-type/')
  async checkCardVender(
    @Body() checkCardVender: CheckCardVender,
  ) {
    return await this.cardBankService.checkCardVender(checkCardVender);
  }

  //  @Get('create-tabapay-key/')
  // async getNewTabapayKey(){
  //  return await this.cardBankService.generateNewKey();
  //}
}
