import { EntityRepository, getRepository, Repository } from 'typeorm';
import { EmployeeCardInfoEntity } from '@entities/EmployeeCardInfo.entity';
import { EmployeeNewCardInfoEntity } from '@entities/EmployeeNewCardInfo.entity';

import { Customer } from '../../entities/Customer.entity';
import { CardDto } from '@dtos/CardDto';
import * as moment from 'moment';
import { ServiceBusSenderService } from '@modules/service-bus-sender/service-bus-sender.service';
import * as config from '../../config/index';
import { NewCardDto } from '@dtos/NewCardDto';
import { InjectRepository } from '@nestjs/typeorm';

const topicName = config.default.topicName;

@EntityRepository(EmployeeCardInfoEntity)
export class EmployeeCardInfoRepository extends Repository<EmployeeCardInfoEntity>{
  constructor(
    private readonly serviceBusService: ServiceBusSenderService,
    @InjectRepository(EmployeeNewCardInfoEntity)
		private readonly employeeNewCardInfoRepo: Repository<EmployeeNewCardInfoEntity>,
  ) {
    super();
  }

    createEmployeeCardInfo(employee: Customer, data: NewCardDto, tabapayAccountID: string, createdIdx:string,isCreatedDto: boolean) {
    const { card_number, expiry_date, cvv, type, nick_name, is_primary } = data;
    const dateMomentObject = moment(expiry_date.replace('/', '/20'), 'MM/YYYY');
    const cardInfo = new EmployeeNewCardInfoEntity();
    // const customerRepository = getRepository(Customer);

    cardInfo.card_number = card_number;
    cardInfo.expiry_date = dateMomentObject.toDate();
    cardInfo.cvv = "cvv";
    cardInfo.type = type;
    cardInfo.customer = employee;
    cardInfo.tabapay_account_id = tabapayAccountID;
    cardInfo.nick_name = nick_name;
    cardInfo.is_primary = is_primary;
    cardInfo.idx = createdIdx; 

    employee.is_debitcard = true;
    //Sending to service bus for saving card
    const serviceBusBodyDto = {
      employee: employee,
      cardInfo: cardInfo
    }
      let serviceBusType = 'bank-create-card-info-save';
      if (isCreatedDto) {
        serviceBusType = 'bank-create-card-info-save';
      } else {
        serviceBusType = 'bank-edit-card-info-save';
      }

    const serviceBusDto = {
      serviceType: serviceBusType,
      body: serviceBusBodyDto,
    };
    // await this.serviceBusService.sendMessage(topicName, serviceBusDto);

    // await customerRepository.save(employee);

    // await cardInfo.save();

    // return cardInfo
    return { serviceBusDto: serviceBusDto, cardInfo: cardInfo};

  }
}
