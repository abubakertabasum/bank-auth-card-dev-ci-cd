import { HttpStatus } from '@nestjs/common';
import * as chai from 'chai';
import chaiHttp = require('chai-http');
import 'mocha';

// import { expose } from 'threads/worker';
// import * as CryptoJS from 'crypto-js';

const enc_key = 'AEON5c56!9E4e#MR';




chai.use(chaiHttp);
const expect = chai.expect;
const should = chai.should();

describe('card-bank API Test', () => {
    const app = 'http://localhost:4000/v1';
    var token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZHgiOiI1OTdDQTBCNC1FNDlELUVCMTEtODVBQS0yODE4NzgzQUI4NjYiLCJlbWFpbCI6ImplbmlzaC5iYWpyYWNoYXJ5YUBvcmJpc3BheS5tZSIsImlhdCI6MTYxOTcxOTE5NiwiZXhwIjoxNjE5ODA1NTk2fQ.GyGca5vtWi4Y6USst9Z2R3YZUQNLDVlSwQ35crcmQhg"
    var idx = '';

    // Get card
    it('should get card', (done) => {
        chai.request(app).get('/card-bank/card/')
            .set({ Authorization: `Bearer ${token}` })
            .end((err, res) => {
                should.exist(res);
                expect(res).to.have.status(201);
                done();
            });

    }).timeout(20000);

    it('should not get card', (done) => {
        chai.request(app).get('/card-bank/card/')
            .end((err, res) => {
                should.exist(res);
                expect(res).to.have.status(401);
                done();
            });
    }).timeout(20000);

    //get card/balance
    it('should get card balance', (done) => {
        chai.request(app).get('/card-bank/card/balance')
            .set({ Authorization: `Bearer ${token}` })
            .end((err, res) => {
                should.exist(res);
                expect(res).to.have.status(201);
                done();
            });
    }).timeout(20000);

    it('should not get card balance', (done) => {
        chai.request(app).get('/card-bank/card/balance')
            .end((err, res) => {
                should.exist(res);
                expect(res).to.have.status(401);
                done();
            });
    }).timeout(20000);

    // create card
    it('should create card', (done) => {
        const data = {
            card_number: '4108810017438537',
            expiry_date: '04/24',
            cvv: '539',
            type: 'DEBIT'
        }
        chai.request(app).post('/card-bank/card/create/')
            .set('content-type', 'application/json')
            .set({ Authorization: `Bearer ${token}` })
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(201);
                done();
            });
    }).timeout(20000);

    it('should not create card', (done) => {
        const data = {
            card_number: '5555555555554444',
            expiry_date: '12/25',
            cvv: '123',
            type: 'CREDIT',
        }
        chai.request(app).post('/card-bank/card/create/')
            .set('content-type', 'application/json')
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(401);
                done();
            });
    }).timeout(20000);

    // Edit card
    it('should Edit card', (done) => {
        const data = {
            card_number: '4108810017438537',
            expiry_date: '04/24',
            cvv: '539',
            type: 'DEBIT',
        }
        chai.request(app).post('/card-bank/card/edit/')
            .set('content-type', 'application/json')
            .set({ Authorization: `Bearer ${token}` })
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(201);
                expect(res.body).to.have.property('card_number', '4108810017438537');
                done();
            });
    }).timeout(20000);

    it('should not edit card', (done) => {
        const data = {
            card_number: '5555555555554444',
            expiry_date: '12/25',
            cvv: '123',
            type: 'CREDIT',
        }
        chai.request(app).post('/card-bank/card/edit/')
            .set('content-type', 'application/json')
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(401);
                done();
            });
    }).timeout(20000);

    // Test Edit card
    it('should Edit card (test)', (done) => {
        const data = {
            card_number: '4108810017438537',
            expiry_date: '04/24',
            cvv: '539',
            type: 'DEBIT',
            createAccount:{
                SC: 200,
                accountID: 'testaccountID'
            },
            queryCard:{
                SC:200
            }
        }
        chai.request(app).post('/card-bank/card/test-edit/')
            .set('content-type', 'application/json')
            .set({ Authorization: `Bearer ${token}` })
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(201);
                expect(res.body).to.have.property('card_number', '4108810017438537');
                done();
            });
    }).timeout(20000);

    it('should not edit card (test)', (done) => {
        const data = {
            card_number: '5555555555554444',
            expiry_date: '12/25',
            cvv: '123',
            type: 'CREDIT',
            createAccount:{
                SC: 200,
                accountID: 'testaccountID'
            },
            queryCard:{
                SC:200
            }
        }
        chai.request(app).post('/card-bank/card/test-edit/')
            .set('content-type', 'application/json')
            .send(data)
            .end((err, res) => {
                should.exist(res);
                res.should.be.an('object');
                expect(res).to.have.status(401);
                done();
            });
    }).timeout(20000);

});