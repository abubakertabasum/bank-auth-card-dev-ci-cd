import { DisbursalBankModule } from '@modules/card-bank/card-bank.module';
import { Logger, Module, OnModuleInit } from '@nestjs/common';
import { ServiceBusReceiverService } from './service-bus-receiver.service';

@Module({
  imports: [DisbursalBankModule],
  providers: [ServiceBusReceiverService],
})
export class ServiceBusReceiverModule implements OnModuleInit {
  constructor(private serviceBusReceiverService: ServiceBusReceiverService) {}

  onModuleInit() {
    const logger = new Logger('Service Bus Receiver On Init Module for Queue');
    logger.log('Initialization...');
    try {
      this.serviceBusReceiverService.receiveMessageAsync();
    } catch (err) {
      logger.error(err);
    }
  }
}
