import {
	HttpException,
	HttpStatus,
	Injectable,
	Logger
} from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm';
import { Status } from '@common/constants/status.enum';
import { Customer } from "@entities/Customer.entity";
// import { EmployeeCardInfoEntity } from "@entities/EmployeeCardInfo.entity";
import { Repository, getConnection} from 'typeorm';
import { EmployeeNewCardInfoEntity } from '@entities/EmployeeNewCardInfo.entity';

const REQUEST_APPROVE_SUCCESS_MSG = 'Request Approved Successfully';
const INTERNAL_SERVER_ERROR_MESSAGE = 'Something Went Wrong';
const logger = new Logger('Create Employee Login DB Writer');

@Injectable()
export class CardBankService {
  constructor(
	@InjectRepository(Customer)
    private readonly customerRepository: Repository<Customer>,
	// @InjectRepository(EmployeeCardInfoEntity)
    // private readonly employeeCardInfoEntityRepository: Repository<EmployeeCardInfoEntity>,
	@InjectRepository(EmployeeNewCardInfoEntity)
    private readonly employeeNewCardInfoEntityRepository: Repository<EmployeeNewCardInfoEntity>,
	
  ) {}

  async saveCardInfo(
	data:any
	): Promise<any> {
	let serviceBusDto = {}
	try{
    await this.customerRepository.save(data.employee);
	console.log("Card Info Object =======================================>"+JSON.stringify(data.cardInfo));
	let is_primary = data.cardInfo.is_primary;
	if(is_primary){
		await getConnection().transaction(async transactionalEntityManager => {
			await transactionalEntityManager.update(
				EmployeeNewCardInfoEntity,
				{ customer: data.employee.id},
				{is_primary: false},
			);
		});
	}

    await this.employeeNewCardInfoEntityRepository.save(data.cardInfo);
		
	}
	catch (err) {
		logger.error(err);
		throw new HttpException(
		INTERNAL_SERVER_ERROR_MESSAGE,
		HttpStatus.INTERNAL_SERVER_ERROR,
		);
	}

}

async editCardInfo( data:any): Promise<any>{
	try{
		console.log('Remove idx for existing card'+data.employee);
		let idx = data.cardInfo.idx;
		let is_primary = data.cardInfo.is_primary;
			if(is_primary){
				await getConnection().transaction(async transactionalEntityManager => {
					await transactionalEntityManager.update(
						EmployeeNewCardInfoEntity,
						{ customer: data.employee.id},
						{is_primary: false},
					);
				});
			}
			await getConnection().transaction(async transactionalEntityManager => {
				await transactionalEntityManager.update(
					EmployeeNewCardInfoEntity,
					{ idx: idx },
					data.cardInfo,
				);
			});
		}
		catch (err) {
			logger.error(err);
			throw new HttpException(
			INTERNAL_SERVER_ERROR_MESSAGE,
			HttpStatus.INTERNAL_SERVER_ERROR,
			);
		}
}

async editNickName(data:any): Promise<any>{
	try{
		console.log('Remove idx for existing card'+data.employee);
		let idx = data.cardIdx;
		let nickName = data.nickName;
			await getConnection().transaction(async transactionalEntityManager => {
				await transactionalEntityManager.update(
					EmployeeNewCardInfoEntity,
					{ idx: idx },
					{nick_name: nickName},
				);
			});
		}
		catch (err) {
			logger.error(err);
			throw new HttpException(
			INTERNAL_SERVER_ERROR_MESSAGE,
			HttpStatus.INTERNAL_SERVER_ERROR,
			);
		}
}

async changeToPrimary( data:any): Promise<any>{
	try{
		console.log('Remove idx for existing card'+data.employee);
		let idx = data.cardIdx;
		let employee_id = data.employee.id;
		await getConnection().transaction(async transactionalEntityManager => {
			await transactionalEntityManager.update(
				EmployeeNewCardInfoEntity,
				{ customer: employee_id},
				{is_primary: false},
			);
		});
			await getConnection().transaction(async transactionalEntityManager => {
				await transactionalEntityManager.update(
					EmployeeNewCardInfoEntity,
					{ idx: idx },
					{is_primary: true},
				);
			});
		}
		catch (err) {
			logger.error(err);
			throw new HttpException(
			INTERNAL_SERVER_ERROR_MESSAGE,
			HttpStatus.INTERNAL_SERVER_ERROR,
			);
		}
}

async deleteCardInfo(
	data:any
	): Promise<any> {
	let serviceBusDto = {}
	try{
	console.log('Remove idx for existing card');
	let idx = data.cardIdx;
	console.log('idx to be removed is ---------> ' + idx);
		await getConnection().transaction(async transactionalEntityManager => {
			await transactionalEntityManager.update(
				EmployeeNewCardInfoEntity,
				{ idx: idx },
				{tabapay_account_id: "", is_obsolete: true},
			);
		});
	}
	catch (err) {
		logger.error(err);
		throw new HttpException(
		INTERNAL_SERVER_ERROR_MESSAGE,
		HttpStatus.INTERNAL_SERVER_ERROR,
		);
	}

}

}
