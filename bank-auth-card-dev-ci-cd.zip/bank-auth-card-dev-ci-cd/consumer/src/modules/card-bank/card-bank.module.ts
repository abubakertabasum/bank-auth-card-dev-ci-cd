import { Module } from '@nestjs/common';
import { CardBankService } from './card-bank.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Customer } from "@entities/Customer.entity";
import { CustomerDevice } from "@entities/CustomerDevice.entity";
// import { EmployeeCardInfoEntity } from "@entities/EmployeeCardInfo.entity";
import { EmployeeDailyLogEntity } from "@entities/EmployeeDailyLog.entity";
import { EmployeePlaidInfo } from "@entities/EmployeePlaidInfo.entity";
import { EmployeeNewCardInfoEntity } from '@entities/EmployeeNewCardInfo.entity';
import { from } from 'rxjs';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Customer,
      CustomerDevice,
      // EmployeeCardInfoEntity,
      EmployeeDailyLogEntity,
      EmployeePlaidInfo,
      EmployeeNewCardInfoEntity
    ]),
  ],
  providers: [CardBankService],
  exports: [CardBankService]
})
export class DisbursalBankModule {}
