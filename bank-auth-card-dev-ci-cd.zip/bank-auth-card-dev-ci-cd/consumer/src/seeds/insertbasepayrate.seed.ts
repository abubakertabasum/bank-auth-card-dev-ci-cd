export const insertBaseRate = `insert into "SaBasepayRate" (employee_type, base_rate) values('Salary', 60), ('Hourly', 7.5)`;
