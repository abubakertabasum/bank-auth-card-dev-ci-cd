export interface Ipagination {
  total_pages: number;
  total_items: number;
  next: string;
  previous: string;
  current_page: number;
  items: any;
}
