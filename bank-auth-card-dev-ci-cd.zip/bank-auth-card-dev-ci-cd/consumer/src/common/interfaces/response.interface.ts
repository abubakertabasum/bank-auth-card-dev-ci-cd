export interface Iresponse {
  statusCode: number;
  message: string;
}
