export enum ChargePayer {
  EMPLOYEE = 'EMPLOYEE',
  EMPLOYER = 'EMPLOYER',
}
