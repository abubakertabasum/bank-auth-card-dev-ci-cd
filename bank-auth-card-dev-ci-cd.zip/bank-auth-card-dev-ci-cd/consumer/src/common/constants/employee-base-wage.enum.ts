export enum EmployeeBaseWage {
  HOURLY = 6,
  MONTHLY = 25,
}
