export enum EmployeeServiceType {
  HOURLY = 'Hourly',
  SALARIED = 'Salary',
  PART_TIME = 'PART_TIME',
  FULL_TIME = 'FULL_TIME',
}
