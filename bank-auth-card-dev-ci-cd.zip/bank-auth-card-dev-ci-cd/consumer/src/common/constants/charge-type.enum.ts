export enum ChargeType {
  PERCENT = 'PERCENT',
  FLAT = 'FLAT',
}
