export enum Operations {
  UPDATE = 'UPDATE',
  CREATE = 'CREATE',
  DELETE = 'DELETE',
  BLOCK = 'BLOCK',
  UNBLOCK = 'UNBLOCK',
}
