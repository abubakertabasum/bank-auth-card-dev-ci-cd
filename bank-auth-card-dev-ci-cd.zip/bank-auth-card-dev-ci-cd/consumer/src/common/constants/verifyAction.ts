export enum VerifyAction {
  APPROVE = 'APPROVE',
  REJECT = 'REJECT',
}
