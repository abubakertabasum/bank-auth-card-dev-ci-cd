export const DEBIT_CARD_REQUEST_PAYLOAD = {
  employee_idx: '',
  action_alias: 'debit_card_requested',
  data: [],
  label: `SINGLE_NOTIFICATION`,
};
