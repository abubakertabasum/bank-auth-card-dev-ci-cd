export const excludedStates = ['IL', 'IN', 'NH', 'NJ', 'NY', 'WV', 'DC', 'PR'];
