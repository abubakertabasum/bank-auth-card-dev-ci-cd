export enum PaymentType {
  ACH = 'ACH',
  INSTANT_PAY_TO_CARD = 'INSTANT_PAY_TO_CARD',
}
