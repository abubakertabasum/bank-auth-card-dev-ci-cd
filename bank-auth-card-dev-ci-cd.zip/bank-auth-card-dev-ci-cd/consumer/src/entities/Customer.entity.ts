import {
Column,
Entity,
Generated,
Index,
OneToMany,
PrimaryGeneratedColumn,
} from 'typeorm';
import { CustomerDevice } from './CustomerDevice.entity';
import { Exclude, Transform } from 'class-transformer';
import { EmployeePlaidInfo } from './EmployeePlaidInfo.entity';
import { EmployeeCardInfoEntity } from './EmployeeCardInfo.entity';
import { EmployeeDailyLogEntity } from './EmployeeDailyLog.entity';
import { EmployeeBankInfo } from './EmployeeBankInfo.entity';
import { EmployeeNewCardInfoEntity } from './EmployeeNewCardInfo.entity';

@Index(['employee_id', 'email'], { unique: true })
@Entity('Customer', { schema: 'dbo' })
export class Customer {
@Column('uuid', {
nullable: false,
name: 'idx',
})
@Generated('uuid')
idx: string;

@Column('varchar', { length: 150, name: 'first_name' })
first_name: string;

@Column('varchar', { length: 150, name: 'middle_name', nullable: true })
middle_name: string | null;

@Column('varchar', { length: 150, name: 'last_name' })
last_name: string;

@Exclude({ toPlainOnly: true })
@Column('varchar', { length: 150, name: 'password', nullable: true })
password: string | null;

@Column('bit', {
name: 'is_password_set',
default: () => '(0)',
})
is_password_set: boolean;

@Column('varchar', { length: 150, name: 'email' })
email: string;

@Column('varchar', { length: 150, name: 'gender', nullable: true })
gender: string | null;

@Column('varchar', { length: 150, name: 'mobile_number' })
mobile_number: string;

@Column('varchar', { length: 150, name: 'zip_code' })
zip_code: string;

@Column('varchar', { length: 150, name: 'hourly_rate' })
hourly_rate: string;

@Column('varchar', { length: 200, name: 'fcm_key', nullable: true })
fcm_key: string | null;

@Column('varchar', { length: 150, name: 'platform', nullable: true })
platform: string | null;

@Column('varchar', { length: 150, name: 'google_id', nullable: true })
google_id: string | null;

@Column('varchar', { length: 150, name: 'fb_id', nullable: true })
fb_id: string | null;

@Column('varchar', { length: 150, name: 'employer_id' })
employer_id: string;

@Transform(({ value }) => value.slice(value.length - 5), { toPlainOnly: true })
@Column('varchar', { length: 150, name: 'ssn_no', nullable: true })
ssn_no: string | null;

@Column('date', { name: 'date_of_birth', nullable: true })
date_of_birth: string | null;

@Column('bit', {
name: 'is_bank_set',
nullable: false,
default: () => '(0)',
})
is_bank_set: boolean;

@Column('datetime', {
name: 'created_on',
default: () => 'getdate()',
})
created_on: Date;

@Column('bit', {
name: 'is_active',
nullable: true,
default: () => '(1)',
})
is_active: boolean | null;

@Column('bit', {
name: 'is_debitcard',
nullable: true,
default: () => '(0)',
})
is_debitcard: boolean | null;

@Column('varchar', { length: 150, name: 'mobile_number_ext', nullable: true })
mobile_number_ext: string | null;

@OneToMany(() => CustomerDevice, customerDevice => customerDevice.customer_id)
customerDevices: CustomerDevice[];

@Column('bit', {
name: 'is_first_time_import',
default: () => '(0)',
})
is_first_time_import: boolean;

@Column('bit', {
nullable: false,
default: () => '(0)',
name: 'is_invited',
})
is_invited: boolean;

@Column('bit', {
nullable: false,
default: () => '(0)',
name: 'is_registered',
})
is_registered: boolean;

@Column('bit', {
nullable: false,
default: () => '(0)',
name: 'sa_approved',
})
sa_approved: boolean;

@Column('varchar', {
nullable: false,
default: () => 'INACTIVE',
name: 'sa_status',
})
sa_status: string;

@Exclude({ toPlainOnly: true })
@PrimaryGeneratedColumn({
type: 'integer',
name: 'id',
})
id: number;
@Exclude({ toPlainOnly: true })
@Column('bit', {
nullable: false,
default: () => '(0)',
name: 'is_obsolete',
})
is_obsolete: boolean;

@Exclude({ toPlainOnly: true })
@Column('datetime', {
nullable: true,
default: () => 'getdate()',
name: 'modified_on',
})
modified_on: Date | null;

@Column('varchar', { length: 150, name: 'employee_id' })
employee_id: string;

@Column('varchar', { length: 150, name: 'worker_id', nullable: true })
worker_id: string;

@Exclude({ toPlainOnly: true })
@Column('datetime', { nullable: true, name: 'last_synced' })
last_synced: Date | null;

@Column('varchar', { name: 'worker_type', length: 255, nullable: true })
worker_type: string;

@Column('varchar', { name: 'employment_type', length: 255, nullable: true })
employment_type: string;

@Column('varchar', {
name: 'residential_address',
length: 1000,
nullable: true,
})
residential_address: string;

@Column('varchar', { name: 'department', length: 250, nullable: true })
department: string;

@Column('varchar', { name: 'salary_type', length: 2000, nullable: true })
salary_type: string;

@Column('varchar', { name: 'pay_frequency', length: 2000, nullable: true })
pay_frequency: string;

@OneToMany(() => EmployeePlaidInfo, plaid_info => plaid_info.customer, {
eager: true,
})
plaid_infos: EmployeePlaidInfo[];

@OneToMany(() => EmployeeBankInfo, bank_info => bank_info.customer, {
    eager: true,
})
bank_infos: EmployeeBankInfo[];

@OneToMany(() => EmployeeCardInfoEntity, card_info => card_info.customer, {
eager: true,
})
card_infos: EmployeeCardInfoEntity[];

@OneToMany(() => EmployeeNewCardInfoEntity, new_card_info => new_card_info.customer, {
    eager: true,
})
new_card_infos: EmployeeNewCardInfoEntity[];

@OneToMany(() => EmployeeDailyLogEntity, daily_log => daily_log.customer, {
eager: true,
})
daily_logs: EmployeeDailyLogEntity[];
}
